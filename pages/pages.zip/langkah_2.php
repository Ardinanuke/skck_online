<?php
    include "proses_langkah_2.php";
?>
<h1><span class="fa fa-lg fa-edit"></span> Hubungan Keluarga</h1>
<?php
    if(@$_GET['proses'] == "sukses"){
?>
<div class="notif"><span class="fa fa-lg fa-info-circle"></span> &nbsp;Data berhasil disimpan, klik tombol <u style="font-family: opensans-bold; text-decoration:none;">Lanjut</u> untuk melanjutkan!</div>
<?php }elseif(@$_GET['proses'] == "gagal"){ ?>
<div class="notif"><span class="fa fa-lg fa-times-circle"></span> &nbsp;Data gagal disimpan!</div>
<?php }elseif(@$_GET['proses'] == "email"){ ?>
<div class="notif"><span class="fa fa-lg fa-exclamation-circle"></span> &nbsp;Email yang anda masukkan sudah ada!</div>
<?php }elseif(@$_GET['proses'] == "password"){ ?>
<div class="notif"><span class="fa fa-lg fa-exclamation-circle"></span> &nbsp;konfirmasi kata sandi salah!</div>
<?php }elseif(@$_GET['proses'] == "kosong"){ ?>
<div class="notif"><span class="fa fa-lg fa-exclamation-circle"></span> &nbsp;Form pengisian tidak boleh ada yang kosong!</div>
<?php } ?>
<?php
    $val = mfa(mq("select * from pengguna where id_pengguna='".$_SESSION['id_pengguna']."'"));
    if($val['status_registrasi'] != "2"){
        $email = $val['email_pengguna'];
        $tombol = '<a class="tombol_ok" href="?page=langkah_2&type=2">Langkah Selanjutnya</a>';
        $tombol2 = '<a class="tombol_ok" href="?page=langkah_2&type=3">Langkah Selanjutnya</a>';
        $tombol3 = '<a class="tombol_ok" href="?page=langkah_2&type=4">Langkah Selanjutnya</a>';
        $tombol4 = '<a class="tombol_ok" href="?page=langkah_2&type=5">Langkah Selanjutnya</a>';
        $tombol5 = '<a class="tombol_ok" href="?page=langkah_2&type=6">Langkah Selanjutnya</a>';
        $tombol6 = '<a class="tombol_ok" href="?page=langkah_3">Langkah Selanjutnya</a>';
    }else{
        $email = $val['email_pengguna'];
        $tombol = '<input class="tombol_ok" type="submit" title="Simpan" name="tombol_simpan1" value="Simpan">
         <input class="tombol_ok" type="submit" title="Lewati" name="tombol_lewat1" value="Lewati">';
        $tombol2 = '<input class="tombol_ok" type="submit" title="Simpan" name="tombol_simpan2" value="Simpan">
         <input class="tombol_ok" type="submit" title="Lewati" name="tombol_lewat2" value="Lewati">';
        $tombol3 = '<input class="tombol_ok" type="submit" title="Simpan" name="tombol_simpan3" value="Simpan">
         <input class="tombol_ok" type="submit" title="Lewati" name="tombol_lewat3" value="Lewati">';
        $tombol4 = '<input class="tombol_ok" type="submit" title="Simpan" name="tombol_simpan4" value="Simpan">
         <input class="tombol_ok" type="submit" title="Lewati" name="tombol_lewat4" value="Lewati">';
        $tombol5 = '<input class="tombol_ok" type="submit" title="Simpan" name="tombol_simpan5" value="Simpan">
         <input class="tombol_ok" type="submit" title="Lewati" name="tombol_lewat5" value="Lewati">';
        $tombol6 = '<input class="tombol_ok" type="submit" title="Simpan" name="tombol_simpan6" value="Simpan">
         <input class="tombol_ok" type="submit" title="Lewati" name="tombol_lewat6" value="Lewati">';
    }
?>
<?php
    if(@$_GET['type'] == ""){
?>
<h2>1. Istri/Suami</h2>
<form method="post">
    <table>
        <tr>
            <td>Nama</td>
            <td>:</td>
            <td><input type="text" name="nama" placeholder="Nama Istri/Suami"></td>
        </tr>
        <tr>
            <td>Umur</td>
            <td>:</td>
            <td><input type="number" name="umur" placeholder="Umur"></td>
        </tr>
        <tr>
            <td>Agama</td>
            <td>:</td>
            <td><select name="agama">
                <option value=""></option>
                <option value="1">Islam</option>
                <option value="2">Kristen</option>
                <option value="3">Katolik</option>
                <option value="4">Budha</option>
                <option value="5">Hindu</option>
                <option value="6">Konghucu</option>
            </select>
        </tr>
        <tr>
            <td>Kebangsaan</td>
            <td>:</td>
            <td><select name="negara">
                <option value=""></option>
                <option value="1">Indonesia</option>
                <option value="2">Malaysia</option>
                <option value="3">Singapura</option>
                <option value="4">Myanmar</option>
            </select></td>
        </tr>
        <tr>
            <td>Pekerjaan</td>
            <td>:</td>
            <td><input type="text" name="pekerjaan" placeholder="Pekerjaan"></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>:</td>
            <td><textarea name="alamat" maxlength="100" placeholder="Alamat Anda.."></textarea></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td><?php echo $tombol; ?></td>
        </tr>
    </table>
</form>
<?php }elseif(@$_GET['type'] == "2"){ ?>
<h2>2. Bapak Sendiri</h2>
<form method="post">
    <table>
        <tr>
            <td>Nama</td>
            <td>:</td>
            <td><input type="text" name="nama" placeholder="Nama Bapak Sendiri"></td>
        </tr>
        <tr>
            <td>Umur</td>
            <td>:</td>
            <td><input type="number" name="umur" placeholder="Umur"></td>
        </tr>
        <tr>
            <td>Agama</td>
            <td>:</td>
            <td><select name="agama">
                <option value=""></option>
                <option value="1">Islam</option>
                <option value="2">Kristen</option>
                <option value="3">Katolik</option>
                <option value="4">Budha</option>
                <option value="5">Hindu</option>
                <option value="6">Konghucu</option>
            </select>
        </tr>
        <tr>
            <td>Kebangsaan</td>
            <td>:</td>
            <td><select name="negara">
                <option value=""></option>
                <option value="1">Indonesia</option>
                <option value="2">Malaysia</option>
                <option value="3">Singapura</option>
                <option value="4">Myanmar</option>
            </select></td>
        </tr>
        <tr>
            <td>Pekerjaan</td>
            <td>:</td>
            <td><input type="text" name="pekerjaan" placeholder="Pekerjaan"></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>:</td>
            <td><textarea name="alamat" maxlength="100" placeholder="Alamat Anda.."></textarea></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td><?php echo $tombol2; ?></td>
        </tr>
    </table>
</form>
<?php }elseif(@$_GET['type'] == "3"){ ?>
<h2>3. Ibu Sendiri</h2>
<form method="post">
    <table>
        <tr>
            <td>Nama</td>
            <td>:</td>
            <td><input type="text" name="nama" placeholder="Nama Ibu Sendiri"></td>
        </tr>
        <tr>
            <td>Umur</td>
            <td>:</td>
            <td><input type="number" name="umur" placeholder="Umur"></td>
        </tr>
        <tr>
            <td>Agama</td>
            <td>:</td>
            <td><select name="agama">
                <option value=""></option>
                <option value="1">Islam</option>
                <option value="2">Kristen</option>
                <option value="3">Katolik</option>
                <option value="4">Budha</option>
                <option value="5">Hindu</option>
                <option value="6">Konghucu</option>
            </select>
        </tr>
        <tr>
            <td>Kebangsaan</td>
            <td>:</td>
            <td><select name="negara">
                <option value=""></option>
                <option value="1">Indonesia</option>
                <option value="2">Malaysia</option>
                <option value="3">Singapura</option>
                <option value="4">Myanmar</option>
            </select></td>
        </tr>
        <tr>
            <td>Pekerjaan</td>
            <td>:</td>
            <td><input type="text" name="pekerjaan" placeholder="Pekerjaan"></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>:</td>
            <td><textarea name="alamat" maxlength="100" placeholder="Alamat Anda.."></textarea></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td><?php echo $tombol3; ?></td>
        </tr>
    </table>
</form>
<?php }elseif(@$_GET['type'] == "4"){ ?>
<h2>4. Saudara Sekandung/Tiri</h2>
<form method="post">
    <table>
        <tr>
            <td>Nama</td>
            <td>:</td>
            <td><input type="text" name="nama" placeholder="Nama Saudara"></td>
        </tr>
        <tr>
            <td>Umur</td>
            <td>:</td>
            <td><input type="number" name="umur" placeholder="Umur"></td>
        </tr>
        <tr>
            <td>Agama</td>
            <td>:</td>
            <td><select name="agama">
                <option value=""></option>
                <option value="1">Islam</option>
                <option value="2">Kristen</option>
                <option value="3">Katolik</option>
                <option value="4">Budha</option>
                <option value="5">Hindu</option>
                <option value="6">Konghucu</option>
            </select>
        </tr>
        <tr>
            <td>Kebangsaan</td>
            <td>:</td>
            <td><select name="negara">
                <option value=""></option>
                <option value="1">Indonesia</option>
                <option value="2">Malaysia</option>
                <option value="3">Singapura</option>
                <option value="4">Myanmar</option>
            </select></td>
        </tr>
        <tr>
            <td>Pekerjaan</td>
            <td>:</td>
            <td><input type="text" name="pekerjaan" placeholder="Pekerjaan"></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>:</td>
            <td><textarea name="alamat" maxlength="100" placeholder="Alamat Anda.."></textarea></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td><?php echo $tombol4; ?></td>
        </tr>
    </table>
</form>
<?php }elseif(@$_GET['type'] == "5"){ ?>
<h2>5. Data Keluarga Suami/Istri</h2>
<form method="post">
    <table>
        <?php
            $suami = mfa(mq("select * from hub_keluarga where id_pengguna='".$_SESSION['id_pengguna']."' && type_keluarga='1'"));
        ?>
        <tr>
            <td>Suami/Istri</td>
            <td>:</td>
            <td><input type="text" name="nama_suami" placeholder="Nama Suami/Istri" value="<?php echo $suami['nama_keluarga']; ?>"></td>
        </tr>
        <tr>
            <td>Bapak Suami/Istri</td>
            <td>:</td>
            <td><input type="text" name="nama_bapak" placeholder="Nama Bapak Suami/Istri"></td>
        </tr>
        <tr>
            <td>Ibu Suami/Istri</td>
            <td>:</td>
            <td><input type="text" name="nama_ibu" placeholder="Nama Ibu Suami/Istri"></td>
        </tr>
        <tr>
            <td>Saudara Suami/Istri</td>
            <td>:</td>
            <td><input type="text" name="nama_saudara" placeholder="Nama Saudara Suami/Istri"></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>:</td>
            <td><textarea name="alamat" maxlength="100" placeholder="Alamat.."></textarea></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td><?php echo $tombol5; ?></td>
        </tr>
    </table>
</form>
<?php }elseif(@$_GET['type'] == "6"){ ?>
<h2>6. Sanak saudara yang menjadi tanggungan</h2>
<form method="post">
    <table>
        <tr>
            <td>Nama</td>
            <td>:</td>
            <td><input type="text" name="nama_tanggungan" placeholder="Nama Saudara"></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>:</td>
            <td><textarea name="alamat_tanggungan" maxlength="100" placeholder="Alamat Saudara.."></textarea></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td><?php echo $tombol6; ?></td>
        </tr>
    </table>
</form>
<?php } ?>